"""Unit tests for the Teams / Organizations layer: org creation, invitations,
accept-invite, and org-aware credit charging in reserve_job_slot.

These stub the Azure + DB dependencies (same convention as test_dispatch_logic.py)
so the *decision logic* runs locally with no Azure SQL, queue, or ACS access. They
prove:

  - creating an org also creates the admin's own membership row (same transaction)
  - inviting more people than seats leaves the excess in "skipped"
  - accepting an invite: rejects invalid/expired/already-used tokens, blocks joining
    a second org, blocks accepting once the org is full, grants credits on success
  - reserve_job_slot: an org member's job charges organization_members.credits_remaining,
    NOT users.credits_remaining, and a job with no org membership still charges the
    personal balance exactly as before
  - a failed job refunds to whichever pool was actually charged

True *concurrency* guarantees (the UPDLOCK/HOLDLOCK race on accept_invitation, the
sp_getapplock serialization in reserve_job_slot) need a real SQL Server under
concurrent load — these tests prove the single-request decision logic is correct,
not that two simultaneous requests can never both win the last seat. Extending
test_concurrency_integration.py with a real-DB race test is a good next step.

Run:  python -m unittest tests.test_org_teams   (from the backend dir)
"""
import os
import sys
import json
import types
import unittest
from unittest import mock

BACKEND_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if BACKEND_DIR not in sys.path:
    sys.path.insert(0, BACKEND_DIR)


# ── Stub heavy deps BEFORE importing function_app (same convention as
#    test_dispatch_logic.py — see that file for why each stub exists) ────────
def _mod(name, **attrs):
    """Only installs a stub if nothing has claimed this module name yet. This
    matters because test files are run TOGETHER in one process (see the test
    docstring, and how CI invokes `python -m unittest tests.test_dispatch_logic
    tests.test_outbox ... tests.test_org_teams`): all test modules are imported
    up front before any test method runs. If this file unconditionally
    overwrote e.g. shared.gpu_lease with a fresh, unconfigured Mock, it would
    silently replace test_dispatch_logic.py's ALREADY-configured stub — and
    that file re-fetches `sys.modules["shared.gpu_lease"]` fresh in its own
    setUp(), so it would pick up OUR blank stub instead of its own. Guarding
    here (rather than trusting import order) makes this file safe to run
    alone, first, last, or anywhere in between."""
    if name in sys.modules:
        return sys.modules[name]
    m = types.ModuleType(name)
    for k, v in attrs.items():
        setattr(m, k, v)
    sys.modules[name] = m
    return m


class _FakeFunctionApp:
    def __init__(self, *a, **k):
        pass

    def route(self, *a, **k):
        return lambda fn: fn

    def queue_trigger(self, *a, **k):
        return lambda fn: fn

    def timer_trigger(self, *a, **k):
        return lambda fn: fn


class _AuthLevel:
    ANONYMOUS = "anonymous"


class _HttpResponse:
    def __init__(self, body="", status_code=200, mimetype=None):
        self.body = body
        self.status_code = status_code
        self.mimetype = mimetype


class _HttpRequest:
    pass


_mod("azure")
_mod("azure.functions",
     FunctionApp=_FakeFunctionApp, AuthLevel=_AuthLevel,
     HttpResponse=_HttpResponse, HttpRequest=_HttpRequest,
     QueueMessage=type("QueueMessage", (), {}),
     TimerRequest=type("TimerRequest", (), {}))
_mod("azure.storage")
_mod("azure.storage.blob",
     generate_blob_sas=mock.Mock(return_value="sas"),
     BlobSasPermissions=mock.Mock())

_mod("shared.auth",
     validate_token=mock.Mock(return_value={"oid": "admin-1", "email": "admin@acme.com"}),
     get_user_id=mock.Mock(return_value="user-1"))
_mod("shared.db", get_db=mock.Mock(), new_connection=mock.Mock())
_mod("shared.queue_client",
     enqueue_job=mock.Mock(), enqueue_training_job=mock.Mock(),
     _send=mock.Mock(), INFERENCE_QUEUE="inference-jobs", TRAINING_QUEUE="lora-training-jobs")
_mod("shared.blob",
     upload_blob=mock.Mock(), download_blob=mock.Mock(return_value=b""),
     get_blob_client=mock.Mock())
_mod("shared.keyvault", get_secret=mock.Mock(return_value="secret"))
_mod("shared.queue_trigger",
     trigger_container_job=mock.Mock(return_value="exec-123"),
     count_active_job_executions=mock.Mock(return_value=0))


class _NoFaceError(Exception):
    pass


_mod("shared.crops",
     crop_head_and_shoulders=mock.Mock(return_value=b"jpeg"),
     NoFaceError=_NoFaceError)
_mod("shared.training_trigger",
     trigger_training_job=mock.Mock(return_value="train-exec-1"),
     get_execution_status=mock.Mock(return_value="running"))


class _DispatchConfigError(Exception):
    pass


_mod("shared.gpu_lease",
     acquire_dispatch_lease=mock.Mock(return_value="owner-1"),
     release_dispatch_lease=mock.Mock(),
     mark_dispatched=mock.Mock(),
     recent_dispatch_pending=mock.Mock(return_value=False),
     DispatchConfigError=_DispatchConfigError)

# NOTE: shared.org_credits and shared.job_reservation are left REAL (not stubbed)
# — these tests exist specifically to exercise their real logic, same reasoning
# as job_reservation being left real in test_dispatch_logic.py.
# shared.stripe_client and shared.invite_email are also left real: they only need
# `requests` (already installed) and shared.keyvault (stubbed above), so importing
# them costs nothing and needs no faking.

import function_app  # noqa: E402


# ── A minimal fake HTTP request ───────────────────────────────────────────
class FakeRequest:
    """Stands in for func.HttpRequest. route_params and body are the two things
    every Teams endpoint reads besides the Authorization header."""
    def __init__(self, body=None, route_params=None, auth="Bearer test-token"):
        self._body = body if body is not None else {}
        self.route_params = route_params or {}
        self.headers = {"Authorization": auth}

    def get_json(self):
        return self._body


# ── A programmable fake DB connection/cursor ──────────────────────────────
# Branches on SQL text so each test can hand back exactly the rows it needs,
# without a real database. Add a new `elif` here if you add a query these
# tests need to cover — keep the substrings SHORT and SPECIFIC so a small
# wording change in the real SQL doesn't silently stop matching.
class FakeCursor:
    def __init__(self, cfg):
        self.cfg = cfg
        self.rowcount = 0
        self._fetch = None
        self._fetchall_rows = []
        self.executed = cfg.setdefault("executed", [])

    def execute(self, sql, *params):
        self.executed.append((" ".join(sql.split()), params))
        s = sql.lower()
        self._fetchall_rows = []

        if "sp_getapplock" in s:
            self._fetch = (self.cfg.get("applock_rc", 0),)

        # ── org membership lookup (shared/org_credits.get_active_membership) ──
        elif "from organization_members m" in s and "join organizations o" in s:
            self._fetch = self.cfg.get("membership_row")  # None or (org_id, credits, membership_id)

        # ── personal credits (individual pool, no org membership) ──
        elif "select credits_remaining from users" in s:
            self._fetch = (self.cfg.get("personal_credits", 20),)

        # ── daily caps in reserve_job_slot ──
        elif "count(*) from jobs where user_id" in s:
            self._fetch = (self.cfg.get("user_cap_count", 0),)
        elif "count(*) from jobs where created_at" in s:
            self._fetch = (self.cfg.get("global_cap_count", 0),)

        # ── job insert ──
        elif "insert into jobs" in s:
            self._fetch = (self.cfg.get("new_job_id", 999),)

        # ── credit charge (reserve_job_slot) ──
        elif "update organization_members set credits_remaining = credits_remaining -" in s:
            self.rowcount = 1
        elif "update users set credits_remaining = credits_remaining -" in s:
            self.rowcount = 1

        # ── credit refund (_mark_failed) ──
        elif "update organization_members set credits_remaining = credits_remaining +" in s:
            self.rowcount = 1
        elif "update users set credits_remaining = credits_remaining +" in s:
            self.rowcount = 1

        # ── outbox row written alongside the job ──
        elif "insert into outbox" in s:
            self._fetch = (self.cfg.get("new_outbox_id", 12345),)

        # ── create_organization ──
        elif "insert into organizations" in s:
            pass  # no return value read by the caller
        elif "insert into organization_members" in s and "output inserted.membership_id" not in s:
            pass  # create_organization's admin-membership insert (no OUTPUT clause)

        # ── _require_org_admin ──
        elif "from organizations where organization_id = ? and admin_user_id" in s:
            self._fetch = self.cfg.get("org_admin_row")

        # ── create_invitations: seat accounting ──
        elif "count(*) from organization_members where organization_id" in s:
            self._fetch = (self.cfg.get("active_members", 0),)
        elif "count(*) from invitations where organization_id" in s:
            self._fetch = (self.cfg.get("pending_invites", 0),)
        elif "select lower(i.email) from invitations" in s:
            self._fetchall_rows = [(e,) for e in self.cfg.get("already_invited", [])]
        elif "insert into invitations" in s:
            self._fetch = (self.cfg.get("new_invitation_id", "inv-new"),)

        # ── accept_invitation ──
        elif "from invitations with (updlock, holdlock)" in s:
            self._fetch = self.cfg.get("invite_row")  # (id, org_id, status, expires_at) or None
        elif "update invitations set status = 'expired'" in s:
            pass
        elif "select organization_id from organization_members where user_id" in s:
            self._fetch = self.cfg.get("existing_membership")  # (org_id,) or None
        elif "select seats_purchased, credits_per_seat, status from organizations" in s:
            self._fetch = self.cfg.get("org_row")  # (seats, credits_per_seat, status) or None
        elif "insert into organization_members" in s and "output inserted.membership_id" in s:
            self._fetch = (self.cfg.get("new_membership_id", "member-new"),)
        elif "update invitations set status = 'accepted'" in s:
            pass

        else:
            self._fetch = None
        return self

    def fetchall(self):
        return self._fetchall_rows

    def fetchone(self):
        return self._fetch


class FakeConn:
    def __init__(self, cfg):
        self.cfg = cfg
        self.autocommit = True
        self.committed = False
        self.rolled_back = False

    def cursor(self):
        return FakeCursor(self.cfg)

    def commit(self):
        self.committed = True

    def rollback(self):
        self.rolled_back = True

    def close(self):
        pass


def _patched(cfg):
    """Patches BOTH new_connection and get_db to return the same fake connection,
    since different endpoints under test use one or the other."""
    conn = FakeConn(cfg)
    p1 = mock.patch.object(function_app, "new_connection", return_value=conn)
    p2 = mock.patch.object(function_app, "get_db", return_value=conn)
    return conn, p1, p2


def _auth_as(admin_user_id="admin-1", email="admin@acme.com"):
    """Explicitly (re)patches BOTH auth functions this module uses, scoped to one
    test via mock.patch's context-manager form. This does NOT rely on the
    module-level _mod("shared.auth", ...) stub above staying untouched — other
    test files imported into the same process (test_dispatch_logic.py etc.) mutate
    that SAME shared mock object's return_value in their own tests, since
    sys.modules is one shared cache for the whole process. Re-patching per test
    keeps this file correct regardless of what order tests run in or what else
    ran before it."""
    return (
        mock.patch.object(function_app, "validate_token",
                           return_value={"oid": admin_user_id, "email": email}),
        mock.patch.object(function_app, "get_user_id", return_value=admin_user_id),
    )


# ═══════════════════════════════════════════════════════════════════════════
# shared/org_credits.py — the function that decides which pool a job spends from
# ═══════════════════════════════════════════════════════════════════════════
class OrgCreditsTests(unittest.TestCase):
    def test_active_member_of_active_org_uses_org_pool(self):
        from shared.org_credits import effective_credits
        cur = FakeCursor({"membership_row": ("org-1", 7, "member-1")})
        credits, org_id = effective_credits(cur, "user-1", personal_credits=50)
        self.assertEqual((credits, org_id), (7, "org-1"))

    def test_no_membership_falls_back_to_personal_pool(self):
        from shared.org_credits import effective_credits
        cur = FakeCursor({"membership_row": None})
        credits, org_id = effective_credits(cur, "user-1", personal_credits=50)
        self.assertEqual((credits, org_id), (50, None))


# ═══════════════════════════════════════════════════════════════════════════
# reserve_job_slot — org-aware credit charging (shared/job_reservation.py)
# ═══════════════════════════════════════════════════════════════════════════
class ReserveJobSlotOrgTests(unittest.TestCase):
    def _reserve(self, cfg):
        from shared.job_reservation import reserve_job_slot
        conn = FakeConn(cfg)
        with mock.patch("shared.job_reservation.new_connection", return_value=conn), \
             mock.patch("shared.job_reservation.outbox_add", return_value=12345):
            result = reserve_job_slot(
                user_id="user-1", input_blob_path="", job_params="{}",
                per_user_cap=5, global_cap=25, credit_cost=1,
            )
        return result, conn

    def test_org_member_charges_org_pool_not_personal(self):
        cfg = {
            "applock_rc": 0,
            "membership_row": ("org-1", 7, "member-1"),  # 7 org credits available
            "personal_credits": 999,  # should never even be read
            "new_job_id": 42,
        }
        result, conn = self._reserve(cfg)
        self.assertTrue(result.ok)
        self.assertEqual(result.job_id, 42)
        self.assertTrue(conn.committed)

        executed_sql = [sql.lower() for sql, _ in cfg["executed"]]
        org_charges = [s for s in executed_sql
                       if "update organization_members set credits_remaining = credits_remaining -" in s]
        personal_charges = [s for s in executed_sql
                             if "update users set credits_remaining = credits_remaining -" in s]
        self.assertEqual(len(org_charges), 1, "should charge the org pool exactly once")
        self.assertEqual(len(personal_charges), 0, "must NOT touch the personal pool")

        # The job row itself should have been inserted with the org_id, not NULL.
        insert_call = next(p for sql, p in cfg["executed"] if "insert into jobs" in sql.lower())
        self.assertIn("org-1", insert_call)

    def test_org_member_insufficient_org_credits_blocks(self):
        cfg = {
            "applock_rc": 0,
            "membership_row": ("org-1", 0, "member-1"),  # 0 credits left in the org pool
            "personal_credits": 999,  # plenty personally — must NOT be used as a fallback
        }
        result, conn = self._reserve(cfg)
        self.assertFalse(result.ok)
        self.assertEqual(result.reason, "credits")
        self.assertTrue(conn.rolled_back)
        # Nothing should have been charged or inserted.
        executed_sql = [sql.lower() for sql, _ in cfg["executed"]]
        self.assertFalse(any("insert into jobs" in s for s in executed_sql))

    def test_no_membership_charges_personal_pool_as_before(self):
        cfg = {
            "applock_rc": 0,
            "membership_row": None,          # not an org member
            "personal_credits": 20,
            "new_job_id": 43,
        }
        result, conn = self._reserve(cfg)
        self.assertTrue(result.ok)
        self.assertTrue(conn.committed)

        executed_sql = [sql.lower() for sql, _ in cfg["executed"]]
        self.assertTrue(any(
            "update users set credits_remaining = credits_remaining -" in s
            for s in executed_sql))
        insert_call = next(p for sql, p in cfg["executed"] if "insert into jobs" in sql.lower())
        self.assertIsNone(insert_call[-1], "organization_id column should be NULL")

    def test_no_membership_insufficient_personal_credits_blocks(self):
        cfg = {"applock_rc": 0, "membership_row": None, "personal_credits": 0}
        result, conn = self._reserve(cfg)
        self.assertFalse(result.ok)
        self.assertEqual(result.reason, "credits")
        self.assertTrue(conn.rolled_back)


# ═══════════════════════════════════════════════════════════════════════════
# POST /orgs — create_organization
# ═══════════════════════════════════════════════════════════════════════════
class CreateOrganizationTests(unittest.TestCase):
    def test_creates_org_and_admin_membership_in_one_transaction(self):
        cfg = {}
        conn, p1, p2 = _patched(cfg)
        auth1, auth2 = _auth_as("admin-1")
        p1.start(); p2.start(); auth1.start(); auth2.start()
        try:
            req = FakeRequest(body={"name": "Acme Corp", "seats_purchased": 10})
            resp = function_app.create_organization(req)
        finally:
            p1.stop(); p2.stop(); auth1.stop(); auth2.stop()

        self.assertEqual(resp.status_code, 201)
        self.assertTrue(conn.committed)
        self.assertFalse(conn.rolled_back)

        executed_sql = [sql.lower() for sql, _ in cfg["executed"]]
        self.assertTrue(any("insert into organizations" in s for s in executed_sql))
        self.assertTrue(any("insert into organization_members" in s for s in executed_sql),
                         "admin must get their own membership row immediately")

    def test_missing_name_returns_400_before_touching_the_db(self):
        cfg = {}
        conn, p1, p2 = _patched(cfg)
        auth1, auth2 = _auth_as("admin-1")
        p1.start(); p2.start(); auth1.start(); auth2.start()
        try:
            req = FakeRequest(body={"seats_purchased": 5})
            resp = function_app.create_organization(req)
        finally:
            p1.stop(); p2.stop(); auth1.stop(); auth2.stop()
        self.assertEqual(resp.status_code, 400)
        self.assertEqual(cfg.get("executed", []), [])

    def test_zero_seats_rejected(self):
        cfg = {}
        conn, p1, p2 = _patched(cfg)
        auth1, auth2 = _auth_as("admin-1")
        p1.start(); p2.start(); auth1.start(); auth2.start()
        try:
            req = FakeRequest(body={"name": "Acme", "seats_purchased": 0})
            resp = function_app.create_organization(req)
        finally:
            p1.stop(); p2.stop(); auth1.stop(); auth2.stop()
        self.assertEqual(resp.status_code, 400)


# ═══════════════════════════════════════════════════════════════════════════
# POST /orgs/{org_id}/invitations — create_invitations
# ═══════════════════════════════════════════════════════════════════════════
class CreateInvitationsTests(unittest.TestCase):
    def setUp(self):
        self._email_patch = mock.patch.object(
            function_app, "send_invite_email", return_value=True)
        self._email_mock = self._email_patch.start()
        self.addCleanup(self._email_patch.stop)

        auth1, auth2 = _auth_as("admin-1")
        auth1.start(); auth2.start()
        self.addCleanup(auth1.stop)
        self.addCleanup(auth2.stop)

    def test_invites_within_seat_limit_all_created(self):
        cfg = {
            "org_admin_row": ("org-1", 10, 10, "active", "Acme"),  # 10 seats total
            "active_members": 2,
            "pending_invites": 1,
            "already_invited": [],
        }
        conn, p1, p2 = _patched(cfg)
        p1.start(); p2.start()
        try:
            req = FakeRequest(
                body={"emails": ["a@acme.com", "b@acme.com"]},
                route_params={"org_id": "org-1"},
            )
            resp = function_app.create_invitations(req)
        finally:
            p1.stop(); p2.stop()

        self.assertEqual(resp.status_code, 201)
        data = json.loads(resp.body)
        self.assertEqual(len(data["created"]), 2)
        self.assertEqual(len(data["skipped"]), 0)
        self.assertEqual(self._email_mock.call_count, 2)

    def test_invites_beyond_remaining_seats_are_skipped(self):
        # 10 seats, 9 already taken (members + pending) -> only 1 seat left
        cfg = {
            "org_admin_row": ("org-1", 10, 10, "active", "Acme"),
            "active_members": 8,
            "pending_invites": 1,
            "already_invited": [],
        }
        conn, p1, p2 = _patched(cfg)
        p1.start(); p2.start()
        try:
            req = FakeRequest(
                body={"emails": ["a@acme.com", "b@acme.com", "c@acme.com"]},
                route_params={"org_id": "org-1"},
            )
            resp = function_app.create_invitations(req)
        finally:
            p1.stop(); p2.stop()

        data = json.loads(resp.body)
        self.assertEqual(len(data["created"]), 1, "only the one remaining seat should be used")
        self.assertEqual(len(data["skipped"]), 2)
        self.assertTrue(all(s["reason"] == "NO_SEATS_AVAILABLE" for s in data["skipped"]))

    def test_no_seats_left_at_all_returns_409(self):
        cfg = {
            "org_admin_row": ("org-1", 5, 10, "active", "Acme"),
            "active_members": 5,
            "pending_invites": 0,
            "already_invited": [],
        }
        conn, p1, p2 = _patched(cfg)
        p1.start(); p2.start()
        try:
            req = FakeRequest(body={"emails": ["a@acme.com"]}, route_params={"org_id": "org-1"})
            resp = function_app.create_invitations(req)
        finally:
            p1.stop(); p2.stop()
        self.assertEqual(resp.status_code, 409)
        self.assertEqual(self._email_mock.call_count, 0)

    def test_duplicate_and_already_invited_emails_are_skipped_not_double_counted(self):
        cfg = {
            "org_admin_row": ("org-1", 10, 10, "active", "Acme"),
            "active_members": 0,
            "pending_invites": 1,
            "already_invited": ["a@acme.com"],
        }
        conn, p1, p2 = _patched(cfg)
        p1.start(); p2.start()
        try:
            req = FakeRequest(
                # a@acme.com is already invited; the duplicate + differently-cased
                # copy should both collapse to a single skip, not spend a seat twice
                body={"emails": ["A@Acme.com ", "a@acme.com", "new@acme.com"]},
                route_params={"org_id": "org-1"},
            )
            resp = function_app.create_invitations(req)
        finally:
            p1.stop(); p2.stop()
        data = json.loads(resp.body)
        self.assertEqual(len(data["created"]), 1)
        self.assertEqual(data["created"][0]["email"], "new@acme.com")
        self.assertEqual(len(data["skipped"]), 1)
        self.assertEqual(data["skipped"][0]["reason"], "ALREADY_INVITED")

    def test_non_admin_caller_gets_404_not_403(self):
        # _require_org_admin looks up org_id AND admin_user_id together, so a
        # non-owner gets "not found", never confirming the org exists.
        cfg = {"org_admin_row": None}
        conn, p1, p2 = _patched(cfg)
        p1.start(); p2.start()
        try:
            req = FakeRequest(body={"emails": ["a@acme.com"]}, route_params={"org_id": "org-1"})
            resp = function_app.create_invitations(req)
        finally:
            p1.stop(); p2.stop()
        self.assertEqual(resp.status_code, 404)


# ═══════════════════════════════════════════════════════════════════════════
# POST /invitations/{token}/accept — accept_invitation
# ═══════════════════════════════════════════════════════════════════════════
class AcceptInvitationTests(unittest.TestCase):
    def _accept(self, cfg, token="tok-abc", accepting_user="user-2"):
        conn, p1, p2 = _patched(cfg)
        auth1, auth2 = _auth_as(accepting_user)
        p1.start(); p2.start(); auth1.start(); auth2.start()
        try:
            req = FakeRequest(route_params={"token": token})
            resp = function_app.accept_invitation(req)
        finally:
            p1.stop(); p2.stop(); auth1.stop(); auth2.stop()
        return resp, conn

    def test_unknown_token_returns_404(self):
        resp, conn = self._accept({"invite_row": None})
        self.assertEqual(resp.status_code, 404)

    def test_already_accepted_token_returns_409(self):
        resp, conn = self._accept({
            "invite_row": ("inv-1", "org-1", "accepted", None),
        })
        self.assertEqual(resp.status_code, 409)

    def test_expired_token_marks_expired_and_returns_410(self):
        from datetime import datetime, timedelta
        past = datetime.utcnow() - timedelta(days=1)
        cfg = {"invite_row": ("inv-1", "org-1", "pending", past)}
        resp, conn = self._accept(cfg)
        self.assertEqual(resp.status_code, 410)
        executed_sql = [sql.lower() for sql, _ in cfg["executed"]]
        self.assertTrue(any("status = 'expired'" in s for s in executed_sql))
        self.assertTrue(conn.committed, "the expiry write itself should still commit")

    def test_already_member_of_a_different_org_returns_409(self):
        from datetime import datetime, timedelta
        future = datetime.utcnow() + timedelta(days=5)
        cfg = {
            "invite_row": ("inv-1", "org-1", "pending", future),
            "existing_membership": ("org-OTHER",),
        }
        resp, conn = self._accept(cfg)
        self.assertEqual(resp.status_code, 409)
        self.assertEqual(json.loads(resp.body)["error"], "ALREADY_IN_ANOTHER_ORG")

    def test_re_accepting_own_orgs_invite_is_a_friendly_no_op(self):
        from datetime import datetime, timedelta
        future = datetime.utcnow() + timedelta(days=5)
        cfg = {
            "invite_row": ("inv-1", "org-1", "pending", future),
            "existing_membership": ("org-1",),  # already in THIS org
        }
        resp, conn = self._accept(cfg)
        self.assertEqual(resp.status_code, 200)
        self.assertIn("Already a member", json.loads(resp.body)["message"])

    def test_org_full_returns_409(self):
        from datetime import datetime, timedelta
        future = datetime.utcnow() + timedelta(days=5)
        cfg = {
            "invite_row": ("inv-1", "org-1", "pending", future),
            "existing_membership": None,
            "org_row": (5, 10, "active"),  # 5 seats purchased
            "active_members": 5,           # all 5 already filled
        }
        resp, conn = self._accept(cfg)
        self.assertEqual(resp.status_code, 409)
        self.assertEqual(json.loads(resp.body)["error"], "NO_SEATS_AVAILABLE")

    def test_successful_accept_grants_credits_and_marks_invite_accepted(self):
        from datetime import datetime, timedelta
        future = datetime.utcnow() + timedelta(days=5)
        cfg = {
            "invite_row": ("inv-1", "org-1", "pending", future),
            "existing_membership": None,
            "org_row": (10, 10, "active"),  # 10 seats, 10 credits/seat
            "active_members": 3,            # room available
            "new_membership_id": "member-99",
        }
        resp, conn = self._accept(cfg)
        self.assertEqual(resp.status_code, 201)
        data = json.loads(resp.body)
        self.assertEqual(data["membership_id"], "member-99")
        self.assertEqual(data["credits_granted"], 10)
        self.assertTrue(conn.committed)

        executed_sql = [sql.lower() for sql, _ in cfg["executed"]]
        self.assertTrue(any("status = 'accepted'" in s for s in executed_sql))


if __name__ == "__main__":
    unittest.main()